<?php

namespace HSBlogLanding;

class Heading
{

}
