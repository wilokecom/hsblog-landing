<?php

namespace HSBlogWidgets\Helpers;

class CSSHelper
{
}
